# Сборка v43

Проект рассчитан на Java 17 и Gradle 8.9. Извлеките этот архив в корень рабочей папки `project/`, убедитесь, что там находятся `settings.gradle` и `app/build.gradle`, затем выполните `gradle --no-daemon assembleDebug`. APK ожидается в `app/build/outputs/apk/debug/app-debug.apk`.

Для сборки в GitHub Actions используйте workflow, включённый в архив, и архивный файл `CavemanQuest_v43_FIXED_PROJECT.zip` в корне репозитория.
