# Caveman Quest v45 — GLB/WebView fixes

Android WebView-проект с локальными GLB-файлами героя и врага, исправленной загрузкой локальных assets через WebViewAssetLoader, import map для GLTFLoader и улучшенной процедурной анимацией частей моделей.

## Сборка
В корне проекта: `gradle --no-daemon assembleDebug`. Для загрузки Three.js и GLTFLoader требуется интернет. GLB-файлы хранятся локально внутри `app/src/main/assets/models/`.

## Ограничения
Текущие GLB содержат отдельные меши, но не имеют skin/skeleton и встроенных animation clips. Движения имитируются вращением отдельных именованных частей; это не полноценная skeletal animation. APK не собран и не протестирован на физическом устройстве в этой среде.
