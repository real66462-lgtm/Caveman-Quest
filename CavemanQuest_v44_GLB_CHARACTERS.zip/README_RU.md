# Caveman Quest v44 — GLB Character Prototype

Проект включает отдельные GLB-файлы персонажа и врага в `app/src/main/assets/models/`: `caveman_hero.glb` и `cave_goblin.glb`. Three.js GLTFLoader загружает их в существующую сцену. Если сеть или загрузка модели недоступна, остаются процедурные модели-запасной вариант.

## Сборка
Сборка APK выполняется через GitHub Actions. В репозитории workflow должен извлекать архив `CavemanQuest_v44_GLB_CHARACTERS.zip` и публиковать APK как `Caveman-Quest-v44-APK`.

## Важно
Это прототип интеграции GLB-моделей. Геометрия GLB создана процедурно и пока не содержит skeletal rig или встроенных animation clips; движение модели использует простые трансформации Three.js. Полноценные скелетные анимации walk/run/jump/attack — следующий этап. Внешняя загрузка Three.js/GLTFLoader требует сетевого доступа; сами GLB находятся внутри APK.
